export interface Hotel
{
  hotelName: string;
  hotelLocation: string;
  hotelImage: string;
  hotelDescription: string;
}
