export interface City
{
  id: number;
  cityName: string;
}
