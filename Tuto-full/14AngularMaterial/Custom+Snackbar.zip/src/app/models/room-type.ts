export interface RoomType
{
  id: number;
  roomTypeName: string;
  price: number;
  vat: number;
  maxPersons: number;
  checkIn: string;
  checkOut: string;
}
