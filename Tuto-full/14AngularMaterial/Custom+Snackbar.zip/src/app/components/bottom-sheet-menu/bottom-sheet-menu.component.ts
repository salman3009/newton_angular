import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottom-sheet-menu',
  templateUrl: './bottom-sheet-menu.component.html',
  styleUrls: ['./bottom-sheet-menu.component.css']
})
export class BottomSheetMenuComponent implements OnInit
{
  constructor() { }

  ngOnInit(): void
  {
  }
}
