import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MainSourceComponent } from './main-source/main-source.component';
import {CanActivateService} from './can-activate.service';
import {DeactivateService} from './deactivate.service';

const routes: Routes = [
  {path:'loan',loadChildren: () => import('./loan/loan.module').then(m => m.LoanModule)},
  {path:'',component:DashboardComponent},
  {path:'auth',children:[
    {path:'login',component:LoginComponent,canDeactivate:[DeactivateService]},
    {path:'register',component:SignupComponent},
  ]},
  {path:'main/:id',component:MainSourceComponent,canActivate:[CanActivateService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
