import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainSourceComponent } from './main-source.component';

describe('MainSourceComponent', () => {
  let component: MainSourceComponent;
  let fixture: ComponentFixture<MainSourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainSourceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
