import { Component, OnInit } from '@angular/core';
import {GlobalService} from '../global.service';
import { Router,ActivatedRoute } from "@angular/router";
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-main-source',
  templateUrl: './main-source.component.html',
  styleUrls: ['./main-source.component.css']
})
export class MainSourceComponent implements OnInit {

  public email:string='';
  public city:string='';
  public comment:string='';
  public flag:boolean=false;
  public routeParmsSubscription: Subscription;
  
  constructor(public global:GlobalService,private activatedRoute: ActivatedRoute) {
    debugger;
   this.email=this.global.registerForm.email?this.global.registerForm.email:'';
   this.city=this.global.registerForm.city?this.global.registerForm.city:'';
   this.comment=this.global.registerForm.comment?this.global.registerForm.comment:'' 
   this.routeParmsSubscription = this.activatedRoute.params.subscribe((params) => {
    console.log("parasms",params);
  });
  }

  ngOnInit(): void {


  }

  onSubmit(formDetails:NgForm){
    debugger;
  
    if (formDetails.invalid) {
      this.flag=true;
      alert("error");
      return;
    }
    console.log(formDetails.value);
    this.global.accountDetails.push(formDetails.value);
    formDetails.resetForm();
  
  }
}
