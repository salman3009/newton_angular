import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  public registerForm:any={};
  public accountDetails:any[]=[];
  
  constructor() { }
}
