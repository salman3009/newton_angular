import { Injectable } from '@angular/core';
import {GlobalService} from './global.service';
import { Router,CanActivate, ActivatedRouteSnapshot } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class CanActivateService implements CanActivate {

  constructor(public global:GlobalService,public router:Router) { }

  canActivate():boolean{
    debugger;
    if(this.global.registerForm?.valid == true){
      return true;
    }
    else{
      this.router.navigate(['/auth/login'])
      return false;
    }
  
  }

}
