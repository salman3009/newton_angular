import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-check',
  templateUrl: './content-check.component.html',
  styleUrls: ['./content-check.component.css']
})
export class ContentCheckComponent implements OnInit {


  ischecked:boolean=false;
  constructor() { }

  ngOnInit() {
  }

  check()
  {
    debugger;
    this.ischecked=true;
  }
  uncheck()
  {
    this.ischecked=false;
  }

}
