import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentCheckComponent } from './content-check.component';

describe('ContentCheckComponent', () => {
  let component: ContentCheckComponent;
  let fixture: ComponentFixture<ContentCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContentCheckComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
