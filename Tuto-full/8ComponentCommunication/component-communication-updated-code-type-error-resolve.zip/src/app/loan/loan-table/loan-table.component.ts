import { Component, OnInit,Input,Output,EventEmitter,ContentChild } from '@angular/core';
import {ContentCheckComponent} from '../content-check/content-check.component';
@Component({
  selector: 'app-loan-table',
  templateUrl: './loan-table.component.html',
  styleUrls: ['./loan-table.component.css']
})
export class LoanTableComponent implements OnInit {


  //public selectionbox: any[] | undefined
  @ContentChild("selectionbox") selectionbox:ContentCheckComponent | undefined;
  ngAfterViewInit(){
    
  }

  @Input("vehicleDetails")vehicleDetails:any;
  public secureDetails:number=2424;
  
  constructor() { }

  ngOnInit(): void {
  }

  @Output() onSelectedDetails = new EventEmitter();
  onInfo(i:number){
    debugger;
    alert(i);
    this.onSelectedDetails.emit(i);
  }


  onSelectionCheck(){
    debugger;
  console.log(this.selectionbox);
  this.selectionbox?.check();
  }
}
