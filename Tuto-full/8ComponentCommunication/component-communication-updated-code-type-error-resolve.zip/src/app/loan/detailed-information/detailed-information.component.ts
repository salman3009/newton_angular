import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-detailed-information',
  templateUrl: './detailed-information.component.html',
  styleUrls: ['./detailed-information.component.css']
})
export class DetailedInformationComponent implements OnInit {

  @Input("status")status:any;
  @Input("selectedDetails")selectedDetails:any;
  constructor() { }

  ngOnInit(): void {
  }

}
