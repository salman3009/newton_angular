import { TestBed } from '@angular/core/testing';

import { GlobalLoanService } from './global-loan.service';

describe('GlobalLoanService', () => {
  let service: GlobalLoanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GlobalLoanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
