import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoanRoutingModule } from './loan-routing.module';
import { VehicleComponent } from './vehicle/vehicle.component';
import { HouseComponent } from './house/house.component';
import { LoanTableComponent } from './loan-table/loan-table.component';
import { DetailedInformationComponent } from './detailed-information/detailed-information.component';
import { ContentCheckComponent } from './content-check/content-check.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    VehicleComponent,
    HouseComponent,
    LoanTableComponent,
    DetailedInformationComponent,
    ContentCheckComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    LoanRoutingModule
  ]
})
export class LoanModule { }
