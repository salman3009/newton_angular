import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VehicleComponent } from './vehicle/vehicle.component';
import { HouseComponent } from './house/house.component';

const routes: Routes = [
  {path:'vehicle',component:VehicleComponent},
  {path:'house',component:HouseComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoanRoutingModule { }
