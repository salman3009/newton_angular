import { Component, OnInit,ViewChild } from '@angular/core';
import {LoanTableComponent} from '../loan-table/loan-table.component';
@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {

  public vehicleDetails:any[]=[];
  public selectedDetails:any={};
  public flag:boolean=false;

  constructor() {
    this.vehicleDetails=[{loanId:12345,tenure:36,emi:10000,total:800000,loanStart:'20/05/2021',loanEnd:'20/12/2022'},
    {loanId:12346,tenure:36,emi:10000,total:800000,loanStart:'20/05/2021',loanEnd:'20/12/2022'},
    {loanId:12347,tenure:36,emi:10000,total:800000,loanStart:'20/05/2021',loanEnd:'20/12/2022'}
  ]
   }

  ngOnInit(): void {
  }

  onSelectedEvents(event:any){
    debugger;
    alert("events"+event);
  this.selectedDetails=this.vehicleDetails[event];
  this.flag=true;
  }

  @ViewChild("prj") prj!:LoanTableComponent;
  onSecure(){
    debugger;
    console.log(this.prj.vehicleDetails);
    alert("onsecure");
    this.prj.onSelectionCheck();
  }
}
