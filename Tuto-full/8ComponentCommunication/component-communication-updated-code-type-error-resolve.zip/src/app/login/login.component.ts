import { Component, OnInit } from '@angular/core';
import {GlobalService} from '../global.service';
import { Router } from "@angular/router";
import { FormGroup, FormControl,FormBuilder,Validators} from '@angular/forms';
import {CanComponentDeactivate} from '../deactivate.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit , CanComponentDeactivate {

  public topic:string;
  public canLeave:boolean=false;
  public subTopic:string='';
  public date= new Date();
  public signUpForm: FormGroup;
  public submitted:boolean=false;

  constructor(public global:GlobalService,public router:Router,private formBuilder: FormBuilder) {
    debugger;
    console.log(this.global.registerForm);
    this.topic="Welcome to Login";
    this.subTopic="Please provide valid details";

    // this.signUpForm = new FormGroup({
    //   email: new FormControl("@gmail.com"),
    //   password:new FormControl(""),
    //   row_status:new FormControl('A')

    // });

     this.signUpForm=this.formBuilder.group({
       email:['@gmail.com',[Validators.required,Validators.email]],
       password:['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]]

     })
    

    this.signUpForm.valueChanges.subscribe((value) => {
      console.log(value.email);
      this.canLeave=false;
    });

   }

   get f() { return this.signUpForm.controls; }

  ngOnInit(): void {
  }

  onSubmitClick(){
    debugger;
   // console.log(this.signUpForm.controls);
    this.submitted=true;
    if (this.signUpForm.invalid) {
      alert("Invalid error");
      return;
  }

  alert("hello");
    
    let validateEmail=this.global.registerForm?this.global.registerForm.email?this.global.registerForm.email:null:null;
    let validatePassword=this.global.registerForm?this.global.registerForm.password?this.global.registerForm.password:null:null;
    if(this.signUpForm.value.email== validateEmail && this.signUpForm.value.password == validatePassword){
      this.signUpForm.setValue({
        email:"ddd",
        password:this.signUpForm.value.password+"QERQWERASDFASDFASDFWERQWWERWQERQWER"
      });
      this.global.registerForm['valid']=true;
      let role=123;
      this.canLeave=true;
      console.log("this.signup form",this.signUpForm.value);
     this.router.navigate([`/main/${role}`])
    }
    else{
      alert("error");
    }
    // this.signUpForm.reset();
     this.signUpForm.reset({
       email:'@gmail.com'
     });

  }
}
