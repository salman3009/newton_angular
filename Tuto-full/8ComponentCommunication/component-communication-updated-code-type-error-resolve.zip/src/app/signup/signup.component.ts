import { Component, OnInit } from '@angular/core';
import {GlobalService} from '../global.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public topic:string;
  public subTopic:string='';
  public emailAddress:string='';
  public password:string='';
  public city:string='';
  public comment:string='';
  public gender:string='male';
  public validDomain:string[]=['gmail.com','yahoo.com'];
  public emailValid:boolean=false;
  public erroMessage:string='';
  public date= new Date();

  constructor(public global:GlobalService,public router:Router) { 
    this.topic="Welcome to Registration";
    this.subTopic="Please fill all the details";
  }

  resetFields():void{
  this.emailAddress='';
  }
  OnEmail(){
    this.erroMessage='info';
    this.emailValid=true;
  console.log(this.emailAddress);
  }  
 emptyStringValidation(data:string,type:string){
  if(type=='email' && !data.endsWith('@gmail.com') ){
    this.erroMessage="It should include gmail.com"
    return true;
  }
  if(data=='' || data == undefined || data ==null){
    this.erroMessage=type;
    return true;
 }
 return false;
}

  onRegister(){
    debugger;
  if(this.emptyStringValidation(this.emailAddress,'email') || this.emptyStringValidation(this.password,"password error") || this.emptyStringValidation(this.city,"city error") || this.emptyStringValidation(this.comment,"comment error") ){
    this.emailValid=true;
    return;
  }
  this.emailValid=false;
    let registerForm={
    email:this.emailAddress,
    password:this.password,
    city:this.city,
    gender:this.gender,
    comment:this.comment
    }
    console.log(registerForm);
    this.global.registerForm=registerForm;
    this.router.navigate(['/auth/login'])
  }
  
  ngOnInit(): void {
    
  }

}
